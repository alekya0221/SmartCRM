#  GenAI Prompt Playbook for CRM Simulation

## Enriching Pain Point Summaries

**Use Case:** Summarize calls or transcripts into CRM-ready fields.

**Prompt Template:**
> Given the following conversation notes:  
> "[Insert transcript snippet or meeting notes here]"  
> Summarize the customer’s core pain point in one line suitable for CRM enrichment.

**Example Input:**
> “We often over-order inventory and get stuck with unsold stock. Our demand forecast accuracy is poor.”

**Output:**
> **pain_point_summary**: "Inaccurate demand forecasting leading to inventory overstock and revenue leakage."

---

##  Personalized Nurturing Email Generator

**Use Case:** Generate reactivation or warm nudges based on lead profile.

**Prompt Template:**
> Write a warm, personalized email for a [industry] lead with intent score [score].  
> They attended a [event type] last week but haven’t responded since. Keep it human but data-aware.

**Example Input:**
> Industry: EdTech, Intent Score: 72, Event: Product Demo

**Output:**
> “Hi [First Name],  
> It was great having you join the demo last week. In case you're still exploring how to scale your EdTech platform with confidence, I’d be happy to share more insights tailored to your goals.  
> Looking forward to reconnect