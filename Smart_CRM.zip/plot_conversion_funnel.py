import pandas as pd
import plotly.express as px

df = pd.read_csv("leads_with_stages.csv")

counts = df["simulated_stage"].value_counts().reindex(["Lead", "MQL", "SQL", "Customer"]).fillna(0)
funnel_df = counts.reset_index()
funnel_df.columns = ["Stage", "Leads"]

fig = px.funnel(funnel_df, x="Leads", y="Stage", title="🧭 Simulated Conversion Funnel")
fig.update_traces(marker_color="steelblue")
fig.show()

fig.write_html("conversion_funnel.html")
print(" Funnel chart saved to conversion_funnel.html — open in browser to view.")
