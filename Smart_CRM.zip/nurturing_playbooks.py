import pandas as pd
from datetime import datetime

# === CONFIG ===
INPUT_FILE = "leads_with_feedback_flags.csv"
OUTPUT_FILE = "leads_with_nurture_tracks.csv"
TODAY = datetime.today()

# === LOGIC ===
def assign_track(row):
    intent = row["intent_score"]
    engaged = row["engagement_health"]
    
    if engaged == "Active" and intent >= 70:
        return "Conversion Nudges"
    elif engaged == "Stale — move to nurturing track" and intent >= 40:
        return "Reactivation Track"
    elif engaged.startswith("Dormant"):
        return "Education Track"
    else:
        return "Monitor / No Action"

df = pd.read_csv(INPUT_FILE)
df["nurture_track"] = df.apply(assign_track, axis=1)
df.to_csv(OUTPUT_FILE, index=False)
print(" Leads tagged with nurture tracks.")
