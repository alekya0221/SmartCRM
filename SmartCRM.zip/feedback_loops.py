import pandas as pd
from datetime import datetime

df = pd.read_csv("leads_with_stages.csv")
TODAY = datetime.today()

def dormant_feedback(date_str):
    try:
        last = datetime.strptime(date_str, "%Y-%m-%d")
        days_since = (TODAY - last).days
        if days_since > 90:
            return "Dormant — consider retagging"
        elif days_since > 60:
            return "Stale — move to nurturing track"
        else:
            return "Active"
    except:
        return "Unknown"

df["engagement_health"] = df["last_engaged"].apply(dormant_feedback)
df.to_csv("leads_with_feedback_flags.csv", index=False)
print(" Feedback loop flags saved to: leads_with_feedback_flags.csv")
