import pandas as pd
from datetime import datetime

from log_logic_override import log_override

# Simulate override -Hardcoded for testing purpose
log_override(
    who="Ally",
    what_changed="Lowered SQL threshold from 80 to 70",
    why="Too many high-intent leads stuck in MQL"
)


# === CONFIG ===
INPUT_FILE = "leads_cleaned_1000.csv"
OUTPUT_FILE = "leads_with_stages.csv"
TODAY = datetime.today()

# === LOGIC HELPERS ===
def recent_engagement(date_str, days=30):
    try:
        last = datetime.strptime(date_str, "%Y-%m-%d")
        return (TODAY - last).days <= days
    except:
        return False

def determine_stage(row):
    if row["funnel_stage"] == "Customer":
        return "Customer", "Already converted"
    if row["intent_score"] >= 70 and recent_engagement(row["last_engaged"]):
        return "SQL", "High intent + recent activity"
    if row["intent_score"] >= 50 and recent_engagement(row["last_engaged"]):
        return "MQL", "Moderate intent + recent engagement"
    return "Lead", "Low score or dormant"

# === RUN LOGIC ===
df = pd.read_csv(INPUT_FILE)
df[["simulated_stage", "stage_reason"]] = df.apply(lambda row: pd.Series(determine_stage(row)), axis=1)
df.to_csv(OUTPUT_FILE, index=False)
print(" Funnel stages simulated and saved to:", OUTPUT_FILE)
