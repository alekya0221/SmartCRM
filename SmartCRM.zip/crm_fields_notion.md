# 📋 CRM Fields & Blueprint

##  Core Fields
| Field | Type | Description |
|-------|------|-------------|
| lead_id | ID | Unique lead record |
| created_at | Date | Entry point timestamp |
| funnel_stage | Enum | Lead, MQL, SQL, Customer |
| intent_score | Integer (0-100) | Simulated signal strength |
| last_engaged | Date | Recent activity touchpoint |
| company_size | Enum | "S: 1-10", etc. |
| source | Enum | Facebook, LinkedIn, etc. |
| engagement_channel | Enum | Email, WhatsApp, Call |
| sales_owner | Text | Assigned AE or SDR |

##  Automation Fields
| Field | Type | Logic |
|-------|------|-------|
| simulated_stage | Enum | Updated stage from model |
| stage_reason | Text | Description of trigger path |
| engagement_health | Enum | Dormant, Stale, Active |
| nurture_track | Enum | Conversion / Reactivation / Education |

##  Ownership Rules
- Leads → Marketing
- MQL → Marketing Ops
- SQL → SDR/AE
- Customer → CSM/Account Manager
