import pandas as pd
from datetime import datetime

# Function to append a logic override entry
def log_override(who, what_changed, why, log_path="logic_overrides.csv"):
    today = datetime.now().strftime("%Y-%m-%d")
    entry = pd.DataFrame([{
        "date": today,
        "who_changed_it": who,
        "what_changed": what_changed,
        "why": why
    }])

    try:
        # Append if log exists
        existing = pd.read_csv(log_path)
        updated = pd.concat([existing, entry], ignore_index=True)
    except FileNotFoundError:
        # Start fresh if it doesn't exist
        updated = entry

    updated.to_csv(log_path, index=False, encoding="utf-8")
    print(f" Override logged: {what_changed}")
