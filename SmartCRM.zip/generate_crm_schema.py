import pandas as pd

schema_data = [
    ["lead_id", "ID", "Unique identifier for each lead", "Auto-increment / Primary Key"],
    ["created_at", "Date", "Date lead entered CRM", "None"],
    ["funnel_stage", "Enum", "Original funnel stage classification", "Manual / Initial campaign assignment"],
    ["intent_score", "Integer", "Simulated intent value from 0–100", "Generated via rule or random for simulation"],
    ["last_engaged", "Date", "Last timestamp of lead interaction", "Updated based on engagement timeline"],
    ["company_size", "Enum", "Organization size (e.g., S: 1–10)", "Input or enrichment"],
    ["source", "Enum", "Lead origin channel", "Captured from form/campaign data"],
    ["simulated_stage", "Enum", "Recalculated funnel stage from rules engine", "Set in funnel_stages.py"],
    ["stage_reason", "Text", "Why a lead was assigned to a stage", "Logic-driven explanation field"],
    ["engagement_health", "Enum", "Signal strength (Active, Dormant, etc.)", "Derived in feedback_loops.py"],
    ["nurture_track", "Enum", "Track type for content delivery", "Assigned via nurturing_playbooks.py"],
    ["sales_owner", "Text", "Assigned AE, SDR, or rep", "Assigned manually or by routing logic"]
]

df = pd.DataFrame(schema_data, columns=["field_name", "field_type", "description", "automation_logic"])
df.to_csv("crm_schema.csv", index=False, encoding="utf-8")
print(" Schema saved as crm_schema.csv")
